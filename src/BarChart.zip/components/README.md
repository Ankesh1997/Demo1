### In this Repo we make Custom Bar Chart using rechart liberary

FILE USED FOR THIS
1. BarChart1.js
2. CustomBar.js
3. CustomXAxixTick.js
